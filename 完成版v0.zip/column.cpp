#include "column.h"

/**初始化**/
COLUMN::COLUMN() : m_name("") {}

void COLUMN::set_name(std::string str)
{
	m_name = str;
};

void COLUMN::set_type(int t)
{
	m_type = t;
};

void COLUMN::set_type_string(std::string s)
{
	m_type_string = s;
}

void COLUMN::set_is_primary(bool b)
{
	m_is_primary = b;
} 

void COLUMN::set_can_be_null(bool b)
{
	m_can_be_null = b;
}

void COLUMN::create_value(std::string str)
{
	m_value.push_back(str);
}

/**查找**/
std::string &COLUMN::operator[](const int &k)
{
	return m_value[k];
}

/**获取信息**/
int COLUMN::get_type() { return m_type; } 

std::string &COLUMN::get_name() { return m_name; } 

bool COLUMN::get_is_primary() { return m_is_primary; } 

bool COLUMN::get_can_be_null()
{

	return m_can_be_null;
}

std::string COLUMN::get_value(int k) { return m_value[k]; }

int COLUMN::get_value_size()
{
	return m_value.size();
}

std::string COLUMN::show_type()
{
	return m_type_string;
}

void COLUMN::show_value(int k)
{
	int total = m_value.size();
	for (int i = 0; i < total; i++)
	{
		if (m_value[i] == m_value[k])
		{
			std::cout << m_value[i] << "\t";
		}
	}
}

/**删除信息**/
void COLUMN::delete_value(int k)
{
	m_value.erase(m_value.begin() + k);
}