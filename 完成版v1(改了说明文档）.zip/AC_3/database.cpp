#include "database.h"

/**初始化**/
DATABASE::DATABASE() : m_name(""){};

void DATABASE::create_table(TABLE t)
{
	m_table.push_back(t);
}

void DATABASE::set_name(std::string str) { m_name = str; }

/**查找**/
TABLE &DATABASE::operator[](const int &k)
{
	return m_table[k];
}

int DATABASE::search_table(const std::string &s)
{
	int length = m_table.size();
	int k = -1;
	for (int i = 0; i < length; i++)
	{
		if (s == m_table[i].get_name())
		{
			k = i;
		}
	}
	return k;
}

/**获取信息**/
std::vector<TABLE> &DATABASE::get_table() { return m_table; }

std::string &DATABASE::get_name() { return m_name; }

void DATABASE::show_tables()
{
	int length = m_table.size();
	if (length == 0)
	{
		//std::cout<< "There aren't any tables!"<<std::endl;
		return;
	}

	std::string *copy_m_table = new std::string[length];

	for (int i = 0; i < length; i++)
	{
		copy_m_table[i] = m_table[i].get_name();
		if (m_table[i].get_name() == "")
		{
			break;
		}
	}

	std::sort(copy_m_table, copy_m_table + length);

	for (int i = 0; i < length; i++)
	{
		std::cout << copy_m_table[i] << std::endl;
	}
	delete[] copy_m_table;
}

/**删除信息**/
void DATABASE::delete_table(std::string str)
{
	for (std::vector<TABLE>::iterator iter = m_table.begin(); iter != m_table.end(); iter++)
		if ((*iter).get_name() == str)
		{
			iter = m_table.erase(iter);
			return;
		}
}
