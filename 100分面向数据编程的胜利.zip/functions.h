#pragma once

#include <iostream>
#include <cstring>
#include <algorithm>
#include <cmath>
#include "system.h"

std::string to_upper(std::string str);
std::string to_lower(std::string str);
void sort_by_pri(TABLE &cur, int *&list);
void read_WhereClause(std::string &t, TABLE &cur, int *&ans);