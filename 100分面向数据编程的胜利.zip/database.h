#pragma once
#include "table.h"
#include <iostream>
#include <vector>
#include <string>

class DATABASE
{
private:
	std::vector<TABLE> m_table;
	std::string m_name;
	

public:

	/**��ʼ��**/
	DATABASE();
	void create_table(TABLE t);
	void set_name(std::string str);

	/**����**/
	TABLE &operator[](const int &k);
	int search_table(const std::string& s);

	/**��ȡ��Ϣ**/
	std::vector<TABLE> &get_table();
	std::string& get_name();
	void show_tables();

	/**ɾ����Ϣ**/
	void delete_table(std::string str);
};
