#include "system.h"
#include "functions.h" //C++里的string没有直接的toupper和tolower，这里还是写一些函数比较方便
using namespace std;

//有可能whereClauses而已放在这里处理，但是目前先放在下面，因为前面的操作不一样
//若输入的是字符串，引号还要再处理
//show类型的函数的输出格式可能还要根据sql改一改
//可以同时用好几个数据库吗，比如USE A,不DROP，继续USE B

/**以下一切的字符串判断都变成大写字母后判断（因为无论什么名称都是对大小写不敏感的）**/
/**所以做到让内部存的都是大写**/
int main()
{
	/**数据管理系统类**/
	SYSTEM sys;

	/**指令**/
	string command;

	/**以下是对各层次类的计数器**/
	//其实这些计数器还不够精细，在大量输入时会出现问题，还需改进，但目前确实可以做到保存当前处理对象
	int database_num = 0;
	int table_num = 0;
	int column_num = 0;

	/**以下是对各层次目前所在上一层的指示器（上一层的下标）**/
	int present_database = 0;
	int present_table = 0;
	int present_column = 0;

	void read_WhereClause(string & t, TABLE & cur, int *&ans); //t是whereclause（前后都没有空格，没有WHERE）
	//这个函数接受一个whereclause返回一个数组头指针，数组下标0的元素储存了一共需要进行操作的行数，从1开始的元素储存了要进行操作的行下标

	/**输入指令**/				  //当然对错误指令的判断也是很重要的，接下来会加上
	while (getline(cin, command)) //使读入字符串不受空格影响
	{
		int len = command.length();   //每行命令最后一个字符是
		string t = to_upper(command); //t用来判断关键字，command用来切割，从而做到列名对大小写敏感，关键字不敏感

		//command = t;//如果去掉这行，就能变成命令对大小写不敏感，命名对大小写敏感

		if (t.substr(0, 16) == "CREATE DATABASE ")
		{
			//cout << "command.substr(16, len - 1): " << command.substr(16, len - 1) << endl;
			DATABASE database;
			database.set_name(command.substr(16, len - 17));
			sys.create_database(database);
			//sys[database_num].set_name(command.substr(16, len - 17));
			//cout << "CREATE DATABASE !" << endl;
			database_num++;
		}

		else if (t.substr(0, 14) == "DROP DATABASE ")
		{
			string dbname = command.substr(14, len - 1 - 14);

			sys.delete_database(dbname);

			database_num--;
			table_num = 0;
			column_num = 0;
		}
		else if (t == "SHOW DATABASES;")
		{
			cout << "Database" << endl;
			sys.show_databases();
		}

		else if (t.substr(0, 4) == "USE ")
		{
			string str = command.substr(4, len - 1 - 4);
			present_database = sys.search_database(str);
			//cout << present_database << endl;
			//cout << sys[present_database].get_name() << endl;
		}

		else if (t.substr(0, 13) == "CREATE TABLE ")
		{
			int bracket = command.find("("); //第一个括号的位置
			/**表名赋值**/
			string str = command.substr(13, bracket - 13);
			TABLE table;
			table.set_name(str);
			sys[present_database].create_table(table);
			/*present_table = table_num;
			cout << "present_table: " << present_table << endl;*/

			/**不断截断找对应信息**/
			//info-table存的是在处理的创建条件括号里的字符串（不包括括号）
			string info_table = command.substr(bracket + 1, len - 3 - bracket);
			string keyname = ""; //这个字符串用来储存主键的名字
			/*cout << "info_table: " << info_table << endl;*/

			int comma = info_table.find(", ");

			/**开始对各column赋值**/

			int count = 0; //count记录总共的列的数量，包括primary key列
			int comma1 = comma;
			string info_table1 = info_table;
			while (comma1 > -1)
			{
				info_table1 = info_table1.substr(comma1 + 2);
				comma1 = info_table1.find(",");
				count++;
			} //上面这部分只是统计了有多少个列

			COLUMN *column = new COLUMN[count]; //给这么多个列分配空间

			int index = 0;
			bool end = false;		  //指示当前循环是不是最后一轮循环，如果是，end值为true，不是则为false：
			while (comma > -1 || end) //find函数如果找不到就返回-1
			{
				string attr;
				if (comma > -1)
					attr = info_table.substr(0, comma); //如果这个时候comma不是-1也就是这不是最后一段，就截到下一个逗号的前面一位
				else
					attr = info_table; //否则（是最后一段）就不需要截了
				/*cout << "attr: " << attr << endl;*/

				int blank = attr.find(" ");
				string attrName = attr.substr(0, blank);
				if (attrName == "PRIMARY")
				{
					int left_bracket = attr.find("(");
					int right_bracket = attr.find(")");
					keyname = attr.substr(left_bracket + 1, right_bracket - left_bracket - 1);
				} //如果是主键，那么记录下主键的名字就可以找下一个逗号了
				else
				{
					//cout << "attrName: " << attrName << endl;

					int is_NULL = attr.find(" NOT NULL");
					//cout << "is_NULL: " << is_NULL << endl;

					string type;
					if (is_NULL != -1)
					{
						//把这部分变成大写，保证对大小写不敏感
						type = attr.substr(blank + 1, is_NULL - blank - 1);
					}
					else
					{
						type = attr.substr(blank + 1);
					}

					type = to_upper(type); //变成大写方便后续判断
					//cout << "type: " << type << endl;

					int type_index = -1;
					if (type.find("INT") != -1)
					{
						type_index = 0;
					}
					else if (type.find("DOUBLE") != -1)
					{
						type_index = 1;
					}
					else if (type.find("CHAR") != -1)
					{
						type_index = 2;
					}

					//cout << "type_index： " << type_index << endl;

					if (is_NULL != -1)
					{
						column[index].set_can_be_null(false);
						//cout << "false" << endl;
					}
					else
					{
						column[index].set_can_be_null(true);
					}

					/**对column赋值**/

					column[index].set_name(attrName);
					column[index].set_type(type_index);
					column[index].set_type_string(to_lower(type)); //还是按小写

					/*cout << "table_num: " << table_num << endl;*/

					/*sys[present_database][table_num].create_column(column[index]);*/
					index++;
					column_num++;
				}
				if (end)
					break;
				info_table = info_table.substr(comma + 2);
				comma = info_table.find(",");

				if (comma == -1)
					end = true;
			}

			int prime_key_column = -1;
			if (keyname != "")
			{
				for (int i = 0; i < index; i++)
				{
					if (column[i].get_name() == keyname)
					{
						prime_key_column = i;
						sys[present_database][table_num].prime_index = i;
						column[i].set_is_primary(true);
					}
					else
					{
						column[i].set_is_primary(false);
					}
				}
				/*cout << "prime_key_column: " << prime_key_column << endl;*/
			}

			for (int i = 0; i < index; i++)
			{
				sys[present_database][table_num].create_column(column[i]);
			}
			table_num++;
			delete[] column;
		}

		else if (t.substr(0, 11) == "DROP TABLE ")
		{
			string table_name = command.substr(11, len - 12);

			sys[present_database].delete_table(table_name);
			table_num--;
			column_num = 0;
		}

		else if (t == "SHOW TABLES;")
		{
			cout << "Tables_in_" << sys[present_database].get_name() << endl;
			sys[present_database].show_tables();
		}

		else if (t.substr(0, 18) == "SHOW COLUMNS FROM ")
		{
			int from_location = t.find(" FROM ");
			string table_name = command.substr(18, len - 1 - 18);
			//cout << "table_name: " << table_name << endl;

			present_table = sys[present_database].search_table(table_name);
			//cout << "present_table: " << present_table << endl;

			cout << "Field\tType\tNull\tKey\tDefault\tExtra" << endl;
			sys[present_database][present_table].show_columns_in_table();
		}

		else if (t.substr(0, 12) == "INSERT INTO ")
		{
			int bracket = command.find("("); //��һ�����ŵ�λ��
			/**�ҵ�����**/
			string str = command.substr(12, bracket - 12);
			present_table = sys[present_database].search_table(str);
			int values_location = t.find(" VALUES ");

			/**���Ͻض��Ҷ�Ӧ��Ϣ**/
			string info_table = command.substr(bracket + 1, values_location - 2 - bracket);
			//cout << "info_table: " << info_table << endl;
			string info_table1 = info_table;

			int comma1 = info_table1.find(", ");

			/**�õ�һ��Ҫ������**/
			int comma_num = 0;

			while (comma1 > -1) //find��������Ҳ����ͷ���-1
			{
				info_table1 = info_table1.substr(comma1 + 2);
				comma1 = info_table1.find(",");
				comma_num++;
			}

			/**��ʼ�Ը�column��ֵ**/
			string *attr = new string[comma_num + 1];

			int comma = info_table.find(", ");
			//cout << "info_table: " << info_table << endl;

			for (int i = 0; i < comma_num; i++)
			{
				attr[i] = info_table.substr(0, comma);
				//cout << "attr: " << i << " " << attr[i] << endl;
				info_table = info_table.substr(comma + 2);
				comma = info_table.find(", ");
				//cout << "info_table: " << info_table << endl;
			}
			attr[comma_num] = info_table;
			//cout << "attr[" << comma_num << "]: " << attr[comma_num] << endl;
			/*for (int i = 0; i <= comma_num; i++)
			{
				cout << "attr["<<i<<"]: " << attr[i] << endl;
			}*/

			/**��VALUES�еĶ�Ӧ��Ϣ**/
			string values_table = command.substr(values_location + 9, len - 2 - values_location - 9);
			//cout << "values_table: " << values_table << endl;
			string *value = new string[comma_num + 1];

			int comma2 = values_table.find(", ");
			for (int i = 0; i < comma_num; i++)
			{
				value[i] = values_table.substr(0, comma2);
				values_table = values_table.substr(comma2 + 2);
				comma2 = values_table.find(", ");
				//cout << "value_table: " << values_table << endl;
			}
			value[comma_num] = values_table;

			for (int i = 0; i <= comma_num; i++)
			{
				/**�����Ŵ�����**/
				if (value[i].find('\"') != -1 || value[i].find('\'') != -1)
				{
					value[i] = value[i].substr(1, value[i].length() - 2);
				}
				//cout << "value["<<i<<"]: " << value[i] << endl;
			}

			bool *column_check = new bool[sys[present_database][present_table].get_column_number()];
			for (int i = 0; i < sys[present_database][present_table].get_column_number(); i++)
				column_check[i] = false;

			/**�ҵ���Ӧcolumn**/
			for (int i = 0; i <= comma_num; i++)
			{
				int column_index = sys[present_database][present_table].search_column(attr[i]);
				//cout<<column_index<<' '<<attr[i]<<' '<<value[i]<<endl ;
				column_check[column_index] = true;
				/*if (sys[present_database][present_table][column_index].get_type() == 1)
				{
					double tmp1 = stod(value[i]);
					double tmp2 = floor(tmp1 * 10000.000f + 0.5) / 10000.000f;
					value[i] = to_string(tmp2);
				}*/
				sys[present_database][present_table][column_index].create_value(value[i]);

				/*string mmp=sys[present_database][present_table][column_index].get_value(sys[present_database][present_table][column_index].get_value_size()-1);
				cout<<mmp<<endl;*/
			}
			for (int i = 0; i < sys[present_database][present_table].get_column_number(); i++)
				if (!column_check[i])
					sys[present_database][present_table][i].create_value("NULL");
			sys[present_database][present_table].number_of_entry++;

			delete[] attr;
			delete[] value;
			delete[] column_check;
		}

		/********以下都是关于whereclauses的，这部分要好好处理********/

		else if (t.substr(0, 12) == "DELETE FROM ")
		{
			int where_location = t.find(" WHERE ");
			string table_name = command.substr(12, where_location - 12);	//执行操作的表名
			present_table = sys[present_database].search_table(table_name); //切换到那个表

			string whereClauses = command.substr(where_location + 7, len - where_location - 8);
			/*cout << table_name << endl
				 << whereClauses << endl;*/

			int *del_list = nullptr;
			read_WhereClause(whereClauses, sys[present_database][present_table], del_list);
			for (int i = del_list[0]; i >= 1; i--) //从大往小删就可以解决删除后下标发生变化的问题
			{
				for (int j = 0; j < sys[present_database][present_table].get_column_number(); j++) //对于一行，每一列的数据都要删掉
				{
					sys[present_database][present_table][j].delete_value(del_list[i]);
				}
			}
			sys[present_database][present_table].number_of_entry -= del_list[0];
			delete[] del_list;
			del_list = nullptr;
		}

		else if (t.substr(0, 7) == "UPDATE ")
		{
			int set_location = t.find(" SET ");
			string table_name = command.substr(7, set_location - 7);
			present_table = sys[present_database].search_table(table_name);

			int where_location = t.find(" WHERE ");
			string replacement = command.substr(set_location + 5, where_location - set_location - 5);
			int equal_location = replacement.find("=");
			string attrName0 = replacement.substr(0, equal_location);
			string attrValue0 = replacement.substr(equal_location + 1);
			//将要把attrName0列的数据替换为attrValue0
			int to_set = sys[present_database][present_table].search_column(attrName0);
			string whereClauses = command.substr(where_location + 7, len - where_location - 8);

			int *update_list = nullptr;
			read_WhereClause(whereClauses, sys[present_database][present_table], update_list);
			/*cout << update_list[0] << "xx" << endl;
			for(int i = 1; i <= update_list[0]; i++)cout << update_list[i] << " ";
			cout << endl;*/
			for (int i = 1; i <= update_list[0]; i++)
			{
				if (attrValue0[0] == '\"' || attrValue0[0] == '\'') //如果是字符串的话，要去掉首尾引号
					sys[present_database][present_table][to_set][update_list[i]] = attrValue0.substr(1, attrValue0.length() - 2);
				else //如果不是字符串的话
					sys[present_database][present_table][to_set][update_list[i]] = attrValue0;
			}
			delete[] update_list;
			update_list = nullptr;
		}

		else if (t.substr(0, 7) == "SELECT ") //select attrname from tablename where ...
		{
			int from_location = t.find(" FROM ");
			string attrName0 = command.substr(7, from_location - 7);

			int where_location = t.find(" WHERE ");
			int *select_list = nullptr;

			string table_name;
			if (where_location != -1)
			{
				table_name = command.substr(from_location + 6, where_location - from_location - 6);
			}
			else
			{
				table_name = command.substr(from_location + 6, len - from_location - 7);
			}
			present_table = sys[present_database].search_table(table_name);

			//cout<<attrName0<<' '<<table_name<<endl;
			if (sys[present_database][present_table].number_of_entry == 0)
				continue;

			if (where_location != -1)
			{
				string whereClauses = command.substr(where_location + 7, len - where_location - 8);
				read_WhereClause(whereClauses, sys[present_database][present_table], select_list);
				sort_by_pri(sys[present_database][present_table], select_list);
				if (select_list[0] != 0)
				{
					if (attrName0 == "*")
					{
						for (int i = 0; i < sys[present_database][present_table].get_column_number(); i++)
						{
							cout << sys[present_database][present_table][i].get_name() << "\t";
						}
						cout << endl;
						for (int j = 1; j <= select_list[0]; j++)
						{
							for (int i = 0; i < sys[present_database][present_table].get_column_number(); i++)
							{
								cout << sys[present_database][present_table][i].get_value(select_list[j]) << "\t";
							}
							cout << endl;
						}
					}
					else
					{
						int attr_index = sys[present_database][present_table].search_column(attrName0);
						cout << sys[present_database][present_table][attr_index].get_name() << endl;
						for (int j = 1; j <= select_list[0]; j++)
						{
							cout << sys[present_database][present_table][attr_index].get_value(select_list[j]) << endl;
						}
					}
				}
				else
				{
					//cout<<endl;
				}
			}
			else
			{
				int value_number = sys[present_database][present_table][0].get_value_size();
				select_list = new int[value_number + 1];
				select_list[0] = value_number;
				for (int i = 1; i <= value_number; i++)
					select_list[i] = i - 1;
				sort_by_pri(sys[present_database][present_table], select_list);

				if (attrName0 == "*")
				{
					int column_number = sys[present_database][present_table].get_column_number();
					for (int i = 0; i < column_number; i++)
					{
						cout << sys[present_database][present_table][i].get_name() << "\t";
					}
					cout << endl;

					for (int j = 1; j <= value_number; j++)
					{
						for (int i = 0; i < column_number; i++)
							cout << sys[present_database][present_table][i].get_value(select_list[j]) << "\t";
						cout << endl;
					}
				}
				else
				{
					int attr_index = sys[present_database][present_table].search_column(attrName0);
					cout << sys[present_database][present_table][attr_index].get_name() << endl;

					for (int j = 1; j <= value_number; j++)
					{
						cout << sys[present_database][present_table][attr_index].get_value(select_list[j]) << endl;
					}
				}
			}
			delete[] select_list;
		}
	}
	//system("pause");
	return 0;
}
