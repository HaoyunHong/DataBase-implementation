#include "table.h"
#include "functions.h"

/**��ʼ��**/
TABLE::TABLE() :number_of_entry(0), m_name(""){};

void TABLE::create_column(COLUMN c)
{
	m_column.push_back(c);
}

void TABLE::set_name(std::string str) { m_name = str; }

/**����**/
COLUMN &TABLE::operator[](const int &k)
{
	return m_column[k];
}

int TABLE::search_column(std::string s)
{
	int total = m_column.size();
	int k = -1;
	for (int i = 0; i < total; i++)
	{
		if (m_column[i].get_name() == s)
		{
			k = i;
			break;
		}
	}
	return k;
} //�����ҵ����е��±�

/**��ȡ����**/
std::vector<COLUMN> &TABLE::get_column() { return m_column; }

int TABLE::get_column_number()
{
	return m_column.size();
}

std::string &TABLE::get_name() { return m_name; }

void TABLE::show_column_info()
{
	int total = m_column.size();
	for (int i = 0; i < total; i++)
	{
		std::cout << m_column[i].get_name() << "\t";
	}
	std::cout << std::endl;

	//	std::cout << (m_column[0].get_value())[0] << std::endl;

	/*for (int i = 0; i < total; i++)
	{
		for (int j = 0; j < m_column[0].get_value().size(); j++)
		{
			std::cout << (m_column[i].get_value())[j] << "\t";
		}	
	}*/
	std::cout << std::endl;
}

void TABLE::show_columns_in_table()
{
	int total = m_column.size();
	for (int i = 0; i < total; i++)
	{
		//std::cout << "i: " << i<<std::endl;
		std::string null_yes_no;
		if (!m_column[i].get_can_be_null())
		{
			null_yes_no = "NO";
		}
		else
		{
			null_yes_no = "YES";
		}

		std::string is_prime_key;

		//std::cout << "m_column[" << i << "].get_name(): " << m_column[i].get_name() << std::endl;
		//std::cout << "m_column[" << i << "].get_is_primary(): " << m_column[i].get_is_primary() <<std:: endl;

		if (m_column[i].get_is_primary())
		{
			is_prime_key = "PRI";
		}
		else
		{
			is_prime_key = "";
		}
		std::string is_default = "NULL";
		std::string extra = "";
		//int(11),char(1),EXTRAʲô�Ļ���֪����ʲô����

		//std::cout << "col_name: "<<m_column[i].get_name() << std::endl;
		std::string type_plus = to_lower(m_column[i].show_type());
		if (type_plus == "int")
		{
			type_plus = "int(11)";
		}
		else if (type_plus == "char")
		{
			type_plus = "char(1)";
		}
		std::cout << m_column[i].get_name() << "\t" << type_plus << "\t" << null_yes_no << "\t" << is_prime_key << "\t" << is_default << "\t" << extra << std::endl;
	}
}