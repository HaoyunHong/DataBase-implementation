#include "system.h"

/**���ڳ�ʼ���ĺ���**/
SYSTEM::SYSTEM() : m_database(0){};

void SYSTEM::create_database(DATABASE d)
{
	m_database.push_back(d);
}

/**���ڲ��ҵĺ���**/
DATABASE &SYSTEM::operator[](const int &k)
{
	return m_database[k];
}
std::vector<DATABASE> &SYSTEM::get_database() { return m_database; }

/**���ڻ�ȡ��Ϣ�ĺ���**/
int SYSTEM::search_database(const std::string &s)
{
	int length = m_database.size();
	int k = -1;
	for (int i = 0; i < length; i++)
	{
		if (s == m_database[i].get_name())
		{
			k = i;
		}
	}
	return k;
}

void SYSTEM::show_databases()
{
	int length = m_database.size();
	//std::cout << "length: " << length << std::endl;
	if (length == 0)
	{
		//�Ƿ�������У���ȷ��
		//std::cout << "There aren't any databases!" << std::endl;
		return;
	}

	std::string *copy_m_database = new std::string[length];

	for (int i = 0; i < length; i++)
	{
		copy_m_database[i] = m_database[i].get_name();
		if (m_database[i].get_name() == "")
		{
			break;
		}
		//std::cout << m_database[i].get_name() << std::endl;
	}

	std::sort(copy_m_database, copy_m_database + length);

	for (int i = 0; i < length; i++)
	{
		std::cout << copy_m_database[i] << std::endl;
	}
	delete[] copy_m_database;
}

/**����ɾ����Ϣ�ĺ���**/
void SYSTEM::delete_database(std::string str)
{
	for (std::vector<DATABASE>::iterator iter = m_database.begin(); iter != m_database.end(); iter++)
		if ((*iter).get_name() == str)
		{
			iter = m_database.erase(iter);
			return;
		}
}
