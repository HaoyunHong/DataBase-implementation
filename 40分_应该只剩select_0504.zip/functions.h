#pragma once

#include<iostream>
#include<string>
#include<algorithm>
std::string to_upper(std::string str);
std::string to_lower(std::string str);
//int *read_WhereClause(std::string &t, TABLE &cur);
