#include "functions.h"

/**手动将字符串转化成大写**/
std::string to_upper(std::string str)
{
	for (unsigned int i = 0; i < str.length(); ++i)
	{
		if (str[i] >= 'a' && str[i] <= 'z')
		{
			str[i] = str[i] - 32;
		}
		else
		{
			continue;
		}
	}
	return str;
}

/**手动将字符串转换成小写**/
std::string to_lower(std::string str)
{
	for (unsigned int i = 0; i < str.length(); ++i)
	{
		if (str[i] >= 'A' && str[i] <= 'Z')
		{
			str[i] = str[i] + 32;
		}
		else
		{
			continue;
		}
	}
	return str;
}

/**按照主键的值的大小排序输出行**/
void sort_by_pri(TABLE &cur, int *&list)
{
	int total = list[0], primeindex = cur.prime_index;
	for (int i = 1; i <= total - 1; i++)
		for (int j = 1; j <= total - i; j++)
		{
			if (cur[primeindex].get_type() == 2)
			{
				if (cur[primeindex][list[j]] > cur[primeindex][list[j + 1]])
				{
					int tmp = list[j];
					list[j] = list[j + 1];
					list[j + 1] = tmp;
				}
			}
			if (cur[primeindex].get_type() == 1)
			{
				if (stod(cur[primeindex][list[j]]) > stod(cur[primeindex][list[j + 1]]))
				{
					int tmp = list[j];
					list[j] = list[j + 1];
					list[j + 1] = tmp;
				}
			}
			if (cur[primeindex].get_type() == 0)
			{
				if (stoi(cur[primeindex][list[j]]) > stoi(cur[primeindex][list[j + 1]]))
				{
					int tmp = list[j];
					list[j] = list[j + 1];
					list[j + 1] = tmp;
				}
			}
		}
	return;
}

void read_WhereClause(std::string &t, TABLE &cur, int *&ans) //t是whereclause（前后都没有空格，没有WHERE）
{
	int size = cur.number_of_entry; //总行数
	bool *chk = new bool[size];
	std::string cut;	  //储存刚切下来的那一段字符串
	std::string uppercut; //cut被大写化之后的字符串
	std::string opt[100]; //储存经切割的whereclause
	std::string cmd[100]; //用来复制cal
	std::string cal[100]; //人工字符串栈，用来处理表达式
	int num = 0;		  //opt计数器
	int iter = 0;		  //cal计数器
	int blank = 0;		  //记录空格位置
	int tot = 0;		  //记录符合要求的总行数
	int l = t.length();   //记录whereclause句的总长

	for (int i = 0; i < size; i++)
		chk[i] = false;
	while (t.find(" ") != -1) //切割whereclause
	{
		blank = t.find(" ");
		cut = t.substr(0, blank);
		uppercut = to_upper(cut);
		if (uppercut == "OR" || uppercut == "AND")
		{
			opt[num] = uppercut;
			num++;
		}
		else
		{
			opt[num] = cut;
			num++;
		}
		t = t.substr(blank + 1, l - blank - 1);
	}
	opt[num] = t;
	num++;
	for (int j = 0; j < size; j++)
	{
		iter = 0;
		for (int i = 0; i < num; i++)
		{
			cal[iter] = opt[i];
			if (cal[iter] != "AND" && cal[iter] != "OR") //如果入栈的是一个表达式，直接算出来并填入TRUE或者FALSE
			{
				std::string left, right;
				int l_is_const = -1;
				int r_is_const = -1; //记录左右两个是不是常数,如果不是常数就储存所在列的下标数字
				int mid = 0;
				if (cal[iter].find("<") != -1)
				{
					mid = cal[iter].find("<");
					left = cal[iter].substr(0, mid);
					right = cal[iter].substr(mid + 1, cal[iter].length() - mid - 1);
					for (int i = 0; i < cur.get_column_number(); i++)
					{
						if (cur[i].get_name() == left)
						{
							l_is_const = i;
							break;
						}
					}
					for (int i = 0; i < cur.get_column_number(); i++)
					{
						if (cur[i].get_name() == right)
						{
							r_is_const = i;
							break;
						}
					}
					if (l_is_const != -1 && r_is_const != -1) //如果都不是常数
					{
						if (cur[l_is_const][j] == "NULL" || cur[r_is_const][j] == "NULL")
						{
							cal[iter] = "FALSE";
						}
						else
						{
							if (cur[l_is_const].get_type() == 0) //int
							{
								if (stoi(cur[l_is_const][j]) < stoi(cur[r_is_const][j]))
									cal[iter] = "TRUE";
								else
									cal[iter] = "FALSE";
							}
							else if (cur[l_is_const].get_type() == 1) //double
							{
								if (stod(cur[l_is_const][j]) < stod(cur[r_is_const][j]))
									cal[iter] = "TRUE";
								else
									cal[iter] = "FALSE";
							}
							else //string
							{
								if (cur[l_is_const][j] < cur[r_is_const][j])
									cal[iter] = "TRUE";
								else
									cal[iter] = "FALSE";
							}
						}
					}
					else if (l_is_const != -1 && r_is_const == -1) //左变量右常量
					{
						if (cur[l_is_const][j] == "NULL")
						{
							cal[iter] = "FALSE";
						}
						else
						{
							if (cur[l_is_const].get_type() == 0) //int
							{
								if (stoi(cur[l_is_const][j]) < stoi(right))
									cal[iter] = "TRUE";
								else
									cal[iter] = "FALSE";
							}
							else if (cur[l_is_const].get_type() == 1) //double
							{
								if (stod(cur[l_is_const][j]) < stod(right))
									cal[iter] = "TRUE";
								else
									cal[iter] = "FALSE";
							}
							else //string
							{
								if (cur[l_is_const][j] < right.substr(1, right.length() - 2)) //要去掉常量字符串最外面的那层引号！
									cal[iter] = "TRUE";
								else
									cal[iter] = "FALSE";
							}
						}
					}
					else //左常量右变量
					{
						if (cur[r_is_const][j] == "NULL")
						{
							cal[iter] = "FALSE";
						}
						else
						{
							if (cur[r_is_const].get_type() == 0) //int
							{
								if (stoi(left) < stoi(cur[r_is_const][j]))
									cal[iter] = "TRUE";
								else
									cal[iter] = "FALSE";
							}
							else if (cur[r_is_const].get_type() == 1) //double
							{
								if (stod(left) < stod(cur[r_is_const][j]))
									cal[iter] = "TRUE";
								else
									cal[iter] = "FALSE";
							}
							else //string
							{
								if (left.substr(1, left.length() - 2) < cur[r_is_const][j]) //这里改过了
									cal[iter] = "TRUE";
								else
									cal[iter] = "FALSE";
							}
						}
					}
				}
				else if (cal[iter].find(">") != -1)
				{
					mid = cal[iter].find(">");
					left = cal[iter].substr(0, mid);
					right = cal[iter].substr(mid + 1, cal[iter].length() - mid - 1);
					for (int i = 0; i < cur.get_column_number(); i++)
					{
						if (cur[i].get_name() == left)
						{
							l_is_const = i;
							break;
						}
					}
					for (int i = 0; i < cur.get_column_number(); i++)
					{
						if (cur[i].get_name() == right)
						{
							r_is_const = i;
							break;
						}
					}
					if (l_is_const != -1 && r_is_const != -1) //如果都不是常数
					{
						if (cur[r_is_const][j] == "NULL" || cur[l_is_const][j] == "NULL")
						{
							cal[iter] = "FALSE";
						}
						else
						{
							if (cur[l_is_const].get_type() == 0) //int
							{
								if (stoi(cur[l_is_const][j]) > stoi(cur[r_is_const][j]))
									cal[iter] = "TRUE";
								else
									cal[iter] = "FALSE";
							}
							else if (cur[l_is_const].get_type() == 1) //double
							{
								if (stod(cur[l_is_const][j]) > stod(cur[r_is_const][j]))
									cal[iter] = "TRUE";
								else
									cal[iter] = "FALSE";
							}
							else //string
							{
								if (cur[l_is_const][j] > cur[r_is_const][j])
									cal[iter] = "TRUE";
								else
									cal[iter] = "FALSE";
							}
						}
					}
					else if (l_is_const != -1 && r_is_const == -1) //左变量右常量
					{
						if (cur[l_is_const][j] == "NULL")
						{
							cal[iter] = "FALSE";
						}
						else
						{
							if (cur[l_is_const].get_type() == 0) //int
							{
								if (stoi(cur[l_is_const][j]) > stoi(right))
									cal[iter] = "TRUE";
								else
									cal[iter] = "FALSE";
							}
							else if (cur[l_is_const].get_type() == 1) //double
							{
								if (stod(cur[l_is_const][j]) > stod(right))
									cal[iter] = "TRUE";
								else
									cal[iter] = "FALSE";
							}
							else //string
							{
								if (cur[l_is_const][j] > right.substr(1, right.length() - 2))
									cal[iter] = "TRUE";
								else
									cal[iter] = "FALSE";
							}
						}
					}
					else //左常量右变量
					{
						if (cur[r_is_const][j] == "NULL")
						{
							cal[iter] = "FALSE";
						}
						else
						{
							if (cur[r_is_const].get_type() == 0) //int
							{
								if (stoi(left) > stoi(cur[r_is_const][j]))
									cal[iter] = "TRUE";
								else
									cal[iter] = "FALSE";
							}
							else if (cur[r_is_const].get_type() == 1) //double
							{
								if (stod(left) > stod(cur[r_is_const][j]))
									cal[iter] = "TRUE";
								else
									cal[iter] = "FALSE";
							}
							else //string
							{
								if (left.substr(1, left.length() - 2) > cur[r_is_const][j])
									cal[iter] = "TRUE";
								else
									cal[iter] = "FALSE";
							}
						}
					}
				}
				else if (cal[iter].find("=") != -1)
				{
					mid = cal[iter].find("=");
					left = cal[iter].substr(0, mid);
					right = cal[iter].substr(mid + 1, cal[iter].length() - mid - 1);

					for (int i = 0; i < cur.get_column_number(); i++)
					{
						if (cur[i].get_name() == left)
						{
							l_is_const = i;
							break;
						}
					}
					for (int i = 0; i < cur.get_column_number(); i++)
					{
						if (cur[i].get_name() == right)
						{
							r_is_const = i;
							break;
						}
					}
					/*cout << l_is_const << " " << r_is_const << endl;*/
					if (l_is_const != -1 && r_is_const != -1) //如果都不是常数
					{
						if (cur[r_is_const][j] == "NULL" || cur[l_is_const][j] == "NULL")
						{
							cal[iter] = "FALSE";
						}
						else
						{
							if (cur[l_is_const][j] == cur[r_is_const][j])
								cal[iter] = "TRUE";
							else
								cal[iter] = "FALSE";
						}
					}
					else if (l_is_const != -1 && r_is_const == -1) //左变量右常量
					{
						if (cur[l_is_const][j] == "NULL")
						{
							cal[iter] = "FALSE";
						}
						else
						{
							if (cur[l_is_const].get_type() == 0) //int
							{
								if (stoi(right) == stoi(cur[l_is_const][j]))
									cal[iter] = "TRUE";
								else
									cal[iter] = "FALSE";
							}
							else if (cur[l_is_const].get_type() == 1) //double
							{
								if (stod(right) == stod(cur[l_is_const][j]))
									cal[iter] = "TRUE";
								else
									cal[iter] = "FALSE";
							}
							else //string
							{
								if (right.substr(1, right.length() - 2) == cur[l_is_const][j])
									cal[iter] = "TRUE";
								else
									cal[iter] = "FALSE";
							}
						}
					}
					else //左常量右变量
					{
						if (cur[r_is_const][j] == "NULL")
						{
							cal[iter] = "FALSE";
						}
						else
						{
							if (cur[r_is_const].get_type() == 0) //int
							{
								if (stoi(left) == stoi(cur[r_is_const][j]))
									cal[iter] = "TRUE";
								else
									cal[iter] = "FALSE";
							}
							else if (cur[r_is_const].get_type() == 1) //double
							{
								if (stod(left) == stod(cur[r_is_const][j]))
									cal[iter] = "TRUE";
								else
									cal[iter] = "FALSE";
							}
							else //string
							{
								if (left.substr(1, left.length() - 2) == cur[r_is_const][j])
									cal[iter] = "TRUE";
								else
									cal[iter] = "FALSE";
							}
						}
					}
				}
			}
			iter++;
		}
		for (int i = 0; i < num; i++)
		{
			cmd[i] = cal[i];
		}
		iter = 0; //重置迭代器
		for (int i = 0; i < num; i++)
		{
			cal[iter] = cmd[i];
			if (iter == 0)
			{
				iter++;
				continue;
			} //讨论特殊情况
			if (cal[iter - 1] == "AND")
			{
				if (cal[iter - 2] == "TRUE" && cal[iter] == "TRUE")
					cal[iter - 2] = "TRUE";
				else
					cal[iter - 2] = "FALSE";
				cal[iter - 1] = "";
				cal[iter] = "";
				iter = iter - 1;
			}
			else
				iter++;
		} //计算AND

		for (int i = 0; i < iter; i++)
		{
			cmd[i] = cal[i];
		}

		int numm = iter;
		iter = 0; //重置迭代器

		for (int i = 0; i < numm; i++)
		{
			cal[iter] = cmd[i];
			if (iter == 0)
			{
				iter++;
				continue;
			}
			if (cal[iter - 1] == "OR")
			{
				if (cal[iter - 2] == "TRUE" || cal[iter] == "TRUE")
					cal[iter - 2] = "TRUE";
				else
					cal[iter - 2] = "FALSE";
				cal[iter - 1] = "";
				cal[iter] = "";
				iter = iter - 1;
			}
			else
				iter++;
		} //计算OR

		if (cal[0] == "TRUE")
		{
			chk[j] = true;
			tot++;
		}
		else
		{
			chk[j] = false;
		}
	}
	ans = new int[tot + 1];
	ans[0] = tot; //数组下标为0的元素存储了符合要求的行数总数
	int g = 1;
	for (int i = 0; i < size; i++)
	{
		if (chk[i])
		{
			ans[g] = i;
			g++;
		}
	}
	delete[] chk;
}

/**输入的时候对多个空格，\t, \n 做判断，全部转换成分隔符只有一个空格的情况**/
std::string Standardize(std::string s)
{
	if (s[0] == '\n')
	{
		s = s.substr(1);
	}
	std::string str = s;
	while (s.find("\t") != -1 || s.find("\n") != -1 || s.find("  ") != -1)
	{
		if (s.find("\t") != -1)
		{
			int tab_location = s.find("\t");
			str = s.substr(0, tab_location) + " " + s.substr(tab_location + 1);
		}
		if (s.find("\n") != -1)
		{
			int endl_location = s.find("\n");
			str = s.substr(0, endl_location) + " " + s.substr(endl_location + 1);
		}
		if (s.find("  ") != -1)
		{
			int multi_blank_location = s.find("  ");
			str = s.substr(0, multi_blank_location) + " " + s.substr(multi_blank_location + 2);
		}
		s = str;
	}
	return str;
}