#pragma once
#include "database.h"
#include <iostream>
#include <vector>
#include <string>

class SYSTEM
{
private:
	std::vector<DATABASE> m_database;

public:
	/**初始化**/
	void create_database(DATABASE d);

	/**查找**/
	DATABASE &operator[](const int &k);
	int search_database(const std::string &s);

	/**获取信息**/
	std::vector<DATABASE> &get_database();
	void show_databases();

	/**删除信息**/
	void delete_database(std::string str);
};