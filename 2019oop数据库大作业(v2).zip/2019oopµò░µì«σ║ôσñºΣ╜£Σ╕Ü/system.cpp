#include "system.h"

/**初始化**/
void SYSTEM::create_database(DATABASE d) { m_database.push_back(d); }

/**查找**/
DATABASE &SYSTEM::operator[](const int &k) { return m_database[k]; }

int SYSTEM::search_database(const std::string &s)
{
	int length = m_database.size();
	int k = -1;
	for (int i = 0; i < length; i++)
	{
		if (s == m_database[i].get_name())
		{
			k = i;
		}
	}
	return k;
}

/**获取信息**/
std::vector<DATABASE> &SYSTEM::get_database() { return m_database; }

void SYSTEM::show_databases()
{
	int length = m_database.size();
	if (length == 0)
	{
		return;
	}

	std::string *copy_m_database = new std::string[length];

	for (int i = 0; i < length; i++)
	{
		copy_m_database[i] = m_database[i].get_name();
		if (m_database[i].get_name() == "")
		{
			break;
		}
	}

	std::sort(copy_m_database, copy_m_database + length);

	for (int i = 0; i < length; i++)
	{
		std::cout << copy_m_database[i] << std::endl;
	}
	delete[] copy_m_database;
}

/**删除信息**/
void SYSTEM::delete_database(std::string str)
{
	for (std::vector<DATABASE>::iterator iter = m_database.begin(); iter != m_database.end(); iter++)
		if ((*iter).get_name() == str)
		{
			iter = m_database.erase(iter);
			return;
		}
}
