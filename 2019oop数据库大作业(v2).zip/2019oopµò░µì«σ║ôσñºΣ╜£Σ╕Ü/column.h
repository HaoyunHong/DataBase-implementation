#pragma once
#include <iostream>
#include <vector>
#include <string>
#include <algorithm>

class COLUMN 
{
private:
	std::string m_name;
	bool m_is_primary;				  //是否为主键
	int m_type;						  //用数字表示类型 0=int，1=double，2=char
	std::string m_type_string;		  //用字符串存储类型名称(大写)
	bool m_can_be_null;				  //是否可为null
	std::vector<std::string> m_value; //value的值也用string存储，需要做运算、比较等操作时再转化为对应类型

public:
	/**初始化**/
	COLUMN();
	void set_name(std::string str);
	void set_type(int t);
	void set_type_string(std::string s);
	void set_can_be_null(bool b);
	void set_is_primary(bool b);
	void create_value(std::string s);

	/**查找**/
	std::string &operator[](const int &k);

	/**获取信息**/
	std::string &get_name();
	bool get_is_primary();
	bool get_can_be_null();
	int get_type();
	std::string get_value(int k);
	void show_value(int k);
	std::string show_type();
	int get_value_size();

	/**删除信息**/
	void delete_value(int k);
};
