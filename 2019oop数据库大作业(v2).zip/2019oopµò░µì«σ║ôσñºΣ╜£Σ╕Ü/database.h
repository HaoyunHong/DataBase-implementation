#pragma once
#include "table.h"
#include <iostream>
#include <vector>
#include <string>

class DATABASE
{
private:
	std::vector<TABLE> m_table;
	std::string m_name;

public:
	/**初始化**/
	DATABASE();
	void create_table(TABLE t);
	void set_name(std::string str);

	/**查找**/
	TABLE &operator[](const int &k);
	int search_table(const std::string &s);

	/**获取信息**/
	std::vector<TABLE> &get_table();
	std::string &get_name();
	void show_tables();

	/**删除信息**/
	void delete_table(std::string str);
};
