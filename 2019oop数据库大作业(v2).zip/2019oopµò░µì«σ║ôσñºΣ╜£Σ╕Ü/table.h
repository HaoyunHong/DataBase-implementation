#pragma once
#include "column.h"
#include <iostream>
#include <vector>
#include <string>

class TABLE
{
private:
	std::vector<COLUMN> m_column;
	std::string m_name;

public:
	int prime_index;
	/**初始化**/
	TABLE();
	void set_name(std::string str);
	void create_column(COLUMN c);

	/**查找**/
	COLUMN &operator[](const int &k);
	int search_column(std::string s);

	/**获取信息**/
	std::vector<COLUMN> &get_column();
	int get_column_number();
	int number_of_entry;
	std::string &get_name();
	void show_column_info();
	void show_columns_in_table();
};
